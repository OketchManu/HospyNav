<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:template match="/">
  <html>
    <head>
      <title>NeXus Books - Digital Library</title>
      <!-- Favicon -->
      <link rel="icon" type="image/svg+xml" href="favicon.svg"/>
      <link rel="alternate icon" type="image/png" href="favicon.png"/>
      <link rel="apple-touch-icon" href="favicon.png"/>
      <meta name="theme-color" content="#5865F2"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="description" content="Welcome to NeXus Books - Your Future Digital Library"/>
      
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&amp;display=swap');
        
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
          font-family: 'Space Grotesk', sans-serif;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes glowPulse {
          0% { box-shadow: 0 0 20px rgba(88, 101, 242, 0.3); }
          50% { box-shadow: 0 0 30px rgba(88, 101, 242, 0.5); }
          100% { box-shadow: 0 0 20px rgba(88, 101, 242, 0.3); }
        }

        @keyframes gradientMove {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }

        .loader {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(10, 10, 20, 0.9);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 1000;
          animation: fadeOut 0.5s ease-out 1s forwards;
        }

        .loader::after {
          content: "";
          width: 50px;
          height: 50px;
          border: 3px solid #5865F2;
          border-top-color: transparent;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        @keyframes fadeOut {
          to { opacity: 0; visibility: hidden; }
        }

        body {
          background: linear-gradient(-45deg, #0a0a14, #1a1a2e, #1a1a3e, #1a1a4e);
          background-size: 400% 400%;
          animation: gradientMove 15s ease infinite;
          color: #fff;
          min-height: 100vh;
          padding: 2rem;
        }

        .container {
          max-width: 1400px;
          margin: 0 auto;
        }

        h1 {
          text-align: center;
          font-size: 3.5rem;
          margin-bottom: 3rem;
          background: linear-gradient(45deg, #5865F2, #FF0080);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          animation: fadeIn 0.8s ease-out;
          text-shadow: 0 0 30px rgba(88, 101, 242, 0.3);
        }

        .book-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
          gap: 2rem;
          padding: 1rem;
        }

        .book-card {
          background: rgba(255, 255, 255, 0.05);
          backdrop-filter: blur(10px);
          -webkit-backdrop-filter: blur(10px);
          border-radius: 20px;
          padding: 2rem;
          transition: all 0.3s ease;
          animation: fadeIn 0.8s ease-out;
          position: relative;
          overflow: hidden;
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .book-card:hover {
          transform: translateY(-5px) scale(1.02);
          animation: glowPulse 2s infinite;
          border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .category {
          display: inline-block;
          padding: 0.5rem 1rem;
          border-radius: 50px;
          font-size: 0.9rem;
          font-weight: 500;
          text-transform: uppercase;
          letter-spacing: 1px;
          margin-bottom: 1rem;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .category-children {
          background: linear-gradient(45deg, #FF0080, #7928CA);
          color: white;
        }

        .category-web {
          background: linear-gradient(45deg, #5865F2, #00D4FF);
          color: white;
        }

        .title {
          font-size: 1.8rem;
          margin: 1rem 0;
          color: #fff;
          line-height: 1.3;
        }

        .author {
          color: rgba(255, 255, 255, 0.7);
          font-size: 1.1rem;
          margin-bottom: 0.5rem;
        }

        .description {
          color: rgba(255, 255, 255, 0.6);
          margin: 1rem 0;
          line-height: 1.6;
        }

        .meta {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 1.5rem;
          padding-top: 1rem;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .year, .isbn {
          color: rgba(255, 255, 255, 0.5);
          font-size: 0.9rem;
          line-height: 1.5;
        }

        .price {
          font-size: 1.5rem;
          font-weight: 700;
          color: #5865F2;
          text-shadow: 0 0 20px rgba(88, 101, 242, 0.3);
          position: relative;
        }

        .price::before {
          content: '';
          position: absolute;
          top: -10px;
          right: -10px;
          bottom: -10px;
          left: -10px;
          background: linear-gradient(45deg, #5865F2, #FF0080);
          opacity: 0.1;
          border-radius: 10px;
          z-index: -1;
        }

        @media (max-width: 768px) {
          body {
            padding: 1rem;
          }
          
          .book-grid {
            grid-template-columns: 1fr;
          }
          
          h1 {
            font-size: 2.5rem;
            margin-bottom: 2rem;
          }
          
          .book-card {
            padding: 1.5rem;
          }
          
          .title {
            font-size: 1.5rem;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          * {
            animation: none !important;
            transition: none !important;
          }
        }

        /* Dark mode optimization */
        @media (prefers-color-scheme: dark) {
          .book-card {
            background: rgba(255, 255, 255, 0.03);
          }
        }
      </style>
    </head>
    <body>
      <div class="loader"></div>
      <div class="container">
        <h1>NeXus Books</h1>
        <div class="book-grid">
          <xsl:for-each select="bookstore/book">
            <div class="book-card">
              <span class="category category-{@category}">
                <xsl:value-of select="@category"/>
              </span>
              <h2 class="title">
                <xsl:value-of select="title"/>
              </h2>
              <div class="author">
                by <xsl:value-of select="author"/>
              </div>
              <div class="description">
                <xsl:value-of select="description"/>
              </div>
              <div class="meta">
                <div class="details">
                  <div class="year">Published <xsl:value-of select="year"/></div>
                  <div class="isbn">ISBN: <xsl:value-of select="isbn"/></div>
                </div>
                <div class="price">
                  $<xsl:value-of select="price"/>
                </div>
              </div>
            </div>
          </xsl:for-each>
        </div>
      </div>
    </body>
  </html>
</xsl:template>
</xsl:stylesheet>